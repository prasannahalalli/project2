package com.claimswift.service;

import com.claimswift.model.Role;
import com.claimswift.model.User;
import com.claimswift.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public String login(String email, String password, String roleStr) {

        // Trim inputs to avoid accidental spaces from frontend
        String emailTrimmed = email.trim();
        String passwordTrimmed = password.trim();
        String roleTrimmed = roleStr.trim().toUpperCase();

        // Validate role enum safely
        Role requestedRole;
        try {
            requestedRole = Role.valueOf(roleTrimmed);
        } catch (IllegalArgumentException e) {
            return "INVALID_ROLE";
        }

        // Fetch user by email & password
        Optional<User> userOpt = userRepository.findByEmailAndPassword(emailTrimmed, passwordTrimmed);

        if (userOpt.isEmpty()) {
            return "INVALID_CREDENTIALS";
        }

        User user = userOpt.get();

        // Validate role match
        if (user.getRole() != requestedRole) {
            return "ROLE_MISMATCH";
        }

        // USER must have insurance
        if (requestedRole == Role.USER) {
            String insurance = user.getInsuranceNumber();

            if (insurance == null || insurance.trim().isEmpty()) {
                return "NO_INSURANCE";
            }
        }

        return "SUCCESS";
    }

    public User findUserByEmail(String email) {
        return userRepository.findByEmail(email.trim()).orElse(null);
    }
}
